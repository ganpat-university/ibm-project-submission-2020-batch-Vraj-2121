#!/bin/bash
cd /home/ubuntu/backend
pip install -r requirements.txt