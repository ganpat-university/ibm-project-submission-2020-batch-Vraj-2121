#!/bin/bash
sudo systemctl start gunicorn