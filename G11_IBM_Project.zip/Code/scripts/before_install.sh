#!/bin/bash
# Stop the application before updating
sudo systemctl stop gunicorn
