#!/bin/bash
# Check if the application is running
curl http://localhost/
